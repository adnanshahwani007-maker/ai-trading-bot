# Configuration file
PAIRS = ['BTC/USDT', 'EUR/USD']