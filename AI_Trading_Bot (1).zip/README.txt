How to run:
1. Install Python
2. pip install -r requirements.txt
3. streamlit run app.py