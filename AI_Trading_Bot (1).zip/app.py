# Streamlit entry file

print('AI Bot Loaded')